<div class="error">
    <div class="error-code m-b-10">404 <i class="fa fa-warning"></i></div>
    <div class="error-content">
        <div class="error-message">PAGE NOT FOUND</div>
        <div class="error-desc m-b-20">
            THE PAGE YOU ARE LOOKING DOESN'T EXIST!
        </div>
        <div>
            <a href="javascript:;" onclick="history.back()" class="btn btn-success">Go Back to Previous Page</a>
        </div>
    </div>
</div>
