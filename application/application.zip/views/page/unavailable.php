<div class="error">
    <div class="error-code m-b-10">503 <i class="fa fa-warning"></i></div>
    <div class="error-content">
        <div class="error-message">SERVICE UNAVAILABLE</div>
        <div class="error-desc m-b-20">
            SERVICE IS CURRENTLY UNAVAILABLE!
        </div>
        <div>
            <a href="javascript:;" onclick="history.back()" class="btn btn-success">Go Back to Previous Page</a>
        </div>
    </div>
</div>
