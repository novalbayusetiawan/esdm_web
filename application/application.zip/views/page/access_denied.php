<div class="error">
    <div class="error-code m-b-10">401 <i class="fa fa-warning"></i></div>
    <div class="error-content">
        <div class="error-message">ACCESS DENIED</div>
        <div class="error-desc m-b-20">
            YOU HAVE NO RIGHTS TO ACCEESS THIS PAGE!
        </div>
        <div>
            <a href="javascript:;" onclick="history.back()" class="btn btn-success">Go Back to Previous Page!</a>
        </div>
    </div>
</div>
